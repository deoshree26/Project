SELECT * FROM project.zomata_sql;
use project;


-- Question no:02
SELECT
    MIN(Datekey_Opening) AS min_date,
    MAX(Datekey_Opening) AS max_date
FROM
    project.zomata_sql;
    
    SELECT
    Datekey_Opening,
    YEAR(Datekey_Opening) AS Year,
    MONTH(Datekey_Opening) AS Monthno,
    MONTHNAME(Datekey_Opening) AS Monthfullname,
    CONCAT('Q', QUARTER(Datekey_Opening)) AS Quarter,
    DATE_FORMAT(Datekey_Opening, '%Y-%b') AS YearMonth,
    DAYOFWEEK(Datekey_Opening) AS Weekdayno,
    DAYNAME(Datekey_Opening) AS Weekdayname,
    CASE
        WHEN MONTH(Datekey_Opening) = 4 THEN 'FM1'
        WHEN MONTH(Datekey_Opening) = 5 THEN 'FM2'
        WHEN MONTH(Datekey_Opening) = 6 THEN 'FM3'
        WHEN MONTH(Datekey_Opening) = 7 THEN 'FM4'
        WHEN MONTH(Datekey_Opening) = 8 THEN 'FM5'
        WHEN MONTH(Datekey_Opening) = 9 THEN 'FM6'
        WHEN MONTH(Datekey_Opening) = 10 THEN 'FM7'
        WHEN MONTH(Datekey_Opening) = 11 THEN 'FM8'
        WHEN MONTH(Datekey_Opening) = 12 THEN 'FM9'
        WHEN MONTH(Datekey_Opening) = 1 THEN 'FM10'
        WHEN MONTH(Datekey_Opening) = 2 THEN 'FM11'
        WHEN MONTH(Datekey_Opening) = 3 THEN 'FM12'
    END AS FinancialMonth,
    CONCAT('FQ', 
        CASE
            WHEN MONTH(Datekey_Opening) BETWEEN 4 AND 6 THEN 1
            WHEN MONTH(Datekey_Opening) BETWEEN 7 AND 9 THEN 2
            WHEN MONTH(Datekey_Opening) BETWEEN 10 AND 12 THEN 3
            ELSE 4
        END
    ) AS FinancialQuarter
FROM
    project.zomata_sql;
    
    
    

-- Question no:04
SELECT
    countryname,
    city,
    COUNT(z.RestaurantID) AS number_of_restaurants
FROM
    project.zomata_sql z
JOIN
    project.country_sql c ON z.CountryCode = c.CountryID
GROUP BY
    countryname,
    city
ORDER BY
    countryname,
    city;
    
   -- Question no:05 
    SELECT
    YEAR(Datekey_opening) AS year,
    QUARTER(Datekey_opening) AS quarter,
    MONTH(Datekey_opening) AS month,
    COUNT(RestaurantID) AS number_of_restaurants
FROM
    project.zomata_sql
GROUP BY
    YEAR(Datekey_opening),
    QUARTER(Datekey_opening),
    MONTH(Datekey_opening)
ORDER BY
    YEAR(Datekey_opening),
    QUARTER(Datekey_opening),
    MONTH(Datekey_opening);
    
    
    -- Question no:06
    SELECT
    round(avg(rating),2) as avg_rating,
    count(restaurantid) AS number_of_restaurants
FROM
    project.zomata_sql
GROUP BY
    rating
ORDER BY
    rating DESC;
    
    
   -- Question no:07 
  SELECT
    CASE
        WHEN average_cost_for_two < 500 THEN 'Under 500'
        WHEN average_cost_for_two BETWEEN 500 AND 4000 THEN '500-4000'
        WHEN average_cost_for_two BETWEEN 5000 AND 9000 THEN '5000-9000'
        WHEN average_cost_for_two BETWEEN 10000 AND 50000 THEN '10000-50000'
        WHEN average_cost_for_two BETWEEN 60000 AND 200000 THEN '60000-100000'
        WHEN average_cost_for_two BETWEEN 200000 AND 1000000 THEN '200000-1000000'
        WHEN average_cost_for_two BETWEEN 1000000 AND 5000000 THEN '1000000-5000000'
        ELSE '5000000 and above'
    END AS price_bucket,
    COUNT(restaurantid) AS number_of_restaurants
FROM
    project.zomata_sql
GROUP BY
    price_bucket
ORDER BY
    price_bucket; 
    
    
 -- Question no:08   
  SELECT
    Has_Table_booking,
    COUNT(restaurantid) AS number_of_restaurants,
    ROUND((COUNT(restaurantid) / (SELECT COUNT(restaurantid) FROM project.zomata_sql) * 100), 2) AS percentage_of_restaurants
FROM
    project.zomata_sql
GROUP BY
    Has_Table_booking
ORDER BY
    Has_Table_booking;
    
    
 -- Question no:09   
SELECT
    Has_Online_delivery,
    COUNT(restaurantid) AS number_of_restaurants,
    ROUND((COUNT(restaurantid) / (SELECT COUNT(restaurantid) FROM project.zomata_sql) * 100), 2) AS percentage_of_restaurants
FROM
    project.zomata_sql
GROUP BY
    Has_Online_delivery
ORDER BY
    Has_Online_delivery;
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
